package gna;
public class Main {
    public static void main(String[] args) throws Exception {
        // You can create a board here and see if it works as expected.
        // We also advise you to write some examples in UnitTests.java as well.
    }
}
