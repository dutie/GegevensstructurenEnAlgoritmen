package gna;

import java.util.Arrays;

public class Main {
	/**
	 * Example main function.
	 * 
	 * You can replace this.
	 */
	public static void main(String[] args) {
		System.out.println("Je mag een main methode schrijven (maar dat hoeft niet)");
	}
}
